from django.shortcuts import render, redirect
from cart.cart import Cart
from .models import OrderItem, SetBill
from .forms import OrderCreateForm
from .tasks import order_created
from django.views.generic.edit import CreateView
from django.urls import reverse_lazy
from django.contrib.messages.views import SuccessMessageMixin



def order_create(request):
    cart = Cart(request)
    if request.method == 'POST':
        form = OrderCreateForm(request.POST)
        if form.is_valid():
            order = form.save()
            for item in cart:
                OrderItem.objects.create(order=order,
                                         product=item['product'],
                                         price=item['price'],
                                         quantity=item['quantity'])
            # clear the cart
            cart.clear()
            # launch asynchronous task
            # order_created.delay(order.id)
            # return render(request,
            #               'orders/order/setbill.html',
            #               {'order': order})
            return redirect('orders:payment')
    else:
        form = OrderCreateForm()
    return render(request,
                  'orders/order/create.html',
                  {'cart': cart, 'form': form})



class PaymentCreateView(SuccessMessageMixin, CreateView):
    model = SetBill
    fields = '__all__'
    template_name = "orders/order/setbill.html"
    success_url = reverse_lazy('shop:product_list')
    success_message = "You have successfully ordered"
    